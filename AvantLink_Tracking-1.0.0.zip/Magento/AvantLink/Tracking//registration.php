<?php
/**
 * Copyright (c) AvantLink, All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'AvantLink_Tracking',
    __DIR__
);
