<?php
namespace AvantLink\Tracking\ViewModel;

class GetConfigData implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    private $helperData;

    public function __construct(
        \AvantLink\Tracking\Helper\Data $helperData
    )
    {
        $this->helperData = $helperData;
    }

    public function getSettingValue()
    {
        return $this->helperData->getMerchantId();
    }
}