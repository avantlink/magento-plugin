/**
* This Go cli function will take a GoogleFeeds xml file and output it to a csv file.
* Usage: ./GoogleFeedsXmlToCsv --src=./GoogleFeed.xml --output=./GoogleFeedSample.csv
*
 */

package main

import (
	"encoding/csv"
	"encoding/xml"
	"flag"
	"fmt"
	"os"
	"reflect"
	"regexp"
	"strings"
)

type XMLIterator struct {
	xmlDecoder *xml.Decoder
	element    *xml.StartElement
}

type Item struct {
	Title             string `xml:"title"`
	Link              string `xml:"link"`
	Description       string `xml:"description"`
	Id                string `xml:"id"`
	Brand             string `xml:"brand"`
	ImageLink         string `xml:"image_link"`
	ItemGroupId       string `xml:"item_group_id"`
	Availability      string `xml:"availability"`
	Mpn               string `xml:"mpn"`
	Gtin              string `xml:"gtin"`
	ProductType       string `xml:"product_type"`
	Color             string `xml:"color"`
	Size              string `xml:"size"`
	Gender            string `xml:"gender"`
	Condition         string `xml:"condition"`
	Adult             string `xml:"adult"`
	CustomLabel0      string `xml:"custom_label_0"`
	CustomLabel1      string `xml:"custom_label_1"`
	CustomLabel2      string `xml:"custom_label_2"`
	CustomLabel3      string `xml:"custom_label_3"`
	CustomLabel4      string `xml:"custom_label_4"`
	ShippingLabel     string `xml:"shipping_label"`
	ReturnPolicyLabel string `xml:"return_policy_label"`
	TransitTimeLabel  string `xml:"transit_time_label"`
	AdsRedirect       string `xml:"ads_redirect"`
	CanonicalLink     string `xml:"canonical_link"`
	SalePrice         string `xml:"sale_price"`
	Price             string `xml:"price"`
	ShippingWeight    string `xml:"shipping_weight"`
	Ibc               string `xml:"ibc"`
	ShopName          string `xml:"shop_name"`
}

var sourceFile string
var outputFile string
var limit int

func init() {
	flag.StringVar(&sourceFile, "src", "", "The xml source file to process.")
	flag.StringVar(&outputFile, "output", "", "The csv output file name and location.")
	flag.IntVar(&limit, "limit", 9999999999999, "The max amount of rows you want to output.")

	flag.Parse()
}

func main() {

	flag.Usage = func() {
		fmt.Printf("Usage: %s [options] <csvFile>\nOptions:\n", os.Args[0])
		flag.PrintDefaults()
	}

	if len(sourceFile) <= 0 {
		fmt.Println("You must provide an src file, use --src flag.")
		return
	}
	if len(outputFile) <= 0 {
		fmt.Println("You must provide an output file, use --output flag.")
		return
	}

	xmlFile, err := os.Open(sourceFile)

	if err != nil {
		fmt.Println("Error opening file:", err)
		return
	}

	defer xmlFile.Close()

	file, err := os.Create(outputFile)
	if err != nil {
		fmt.Println("Error outputting file:", err)
		return
	}

	defer file.Close()

	csvWriter := csv.NewWriter(file)
	defer csvWriter.Flush()

	v := reflect.ValueOf(Item{})

	values := make([]string, v.NumField())
	typeOfS := v.Type()

	for i := 0; i < v.NumField(); i++ {
		values[i] = typeOfS.Field(i).Name
	}

	err = csvWriter.Write(values)

	iterator := NewIterator(xmlFile)
	total := 0

	for iterator.Next() {
		total++
		item := &Item{}

		iterator.xmlDecoder.DecodeElement(item, iterator.element)

		v := reflect.ValueOf(*item)
		values := make([]string, v.NumField())

		for i := 0; i < v.NumField(); i++ {
			values[i] = fmt.Sprintf("%v", v.Field(i).Interface())
		}

		cleanItems(values)

		csvWriter.Write(values)

		if total >= limit {
			break
		}

	}
}

func NewIterator(file *os.File) (xi *XMLIterator) {
	xi = &XMLIterator{
		xmlDecoder: xml.NewDecoder(file),
	}
	return
}

// Next iterate through XML document
func (xi *XMLIterator) Next() bool {
	for {
		t, _ := xi.xmlDecoder.Token()

		if t == nil {
			return false
		}

		switch ty := t.(type) {
		case xml.StartElement:
			if ty.Name.Local == "item" {
				xi.element = &ty
				return true
			}
		}
	}
}

func cleanItems(items []string) []string {
	for index, value := range items {
		items[index] = normalizeSpace(value)
	}

	return items
}

func normalizeSpace(s string) string {
	space := regexp.MustCompile(`\s+`)
	s = space.ReplaceAllString(s, " ")
	s = strings.Trim(s, " ")
	return s
}
