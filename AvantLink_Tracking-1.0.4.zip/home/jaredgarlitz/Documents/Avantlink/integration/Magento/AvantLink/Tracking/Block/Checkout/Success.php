<?php
namespace AvantLink\Tracking\Block\Checkout;

use Magento\Checkout\Block\Onepage\Success as MagentoSuccess;

class Success extends MagentoSuccess
{
    //This only exists so we can have a block for the data to pass through.
}
