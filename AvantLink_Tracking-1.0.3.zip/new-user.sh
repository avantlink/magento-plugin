#!/bin/bash
#This script should only be used for creating users that need ftp access for datafeeds.

#***************************************************************************************
#**** If you need to create a user for batch USE THE ARCHES INTERFACE NOT THIS TOOL ****
#***************************************************************************************

# Clear screen for ease of readability
    clear

# Announce Program
    echo "Add Datafeed User"
    echo "=============="
    echo ""


# Prompt for client name
    read -p "Please enter a client name: " clientname

# Confirm, validate, strtolower()
    case "$clientname" in
    *\ * )
           echo "Error: Client name contains a space. Exiting..."
           exit 1
        ;;
    *)
        clientname="$(echo $clientname | tr '[:upper:]' '[:lower:]')"
        read -p "Client name: $clientname. Are you sure? [Y/N]: " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]] ; then
            donothing=1
        else
            echo "Aborting..."
            exit 1
        fi
       ;;
    esac

# Create user
    echo "Adding user..."

    sudo useradd --create-home --groups ftp --shell=/dev/null --home-dir=/home/ftp/$clientname $clientname

    # Catch stderr
    if [ $? -eq 0 ]; then
        echo "user '$clientname' added successfully, /home/ftp/$clientname created successfully."
    else
        echo "There was an error. Aborting..."
        exit 1
    fi

    # create top folder
    sudo chown $clientname: /home/ftp/$clientname

    if [[ $? -eq 0 ]] ; then
        echo "Changed ownership of /home/ftp/$clientname directory."
    else
        echo "There was an error. Aborting..."
        exit 1
    fi

# Password
autogen=1
until [[ $pwsuccess == 1 ]]
do

    #Auto-generate.
    until [[ $autogen == 0 ]]
    do
        echo "Generating random password..."
        password="$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 12 | head -n 1)"

        if [[ $password == "" || $? != 0 ]] ; then
            echo "There was an error auto-generating a password."
            read -p "Try again? [Y/N]: " -n 1 -r
            echo

            if [[ $REPLY =~ ^[Yy]$ ]] ; then
                autogen=1
            else
                read -p "Create manual password? [Y/N]: " -n 1 -r
                    if [[ $REPLY =~ ^[Yy]$ ]] ; then
                        autogen=0
                        manualgen=1
                    else
                        echo "There was an error setting the password. Cannot continue."
                        echo "Please set one using the 'sudo passwd $clientname' command manually."
                        echo "Aborting..."
                        exit 1
                    fi
            fi
        else
            autogen=0
        fi
    done

    # Manual Gen
    if [[ $manualgen == 1 ]] ; then
        until [[ $manualgen == 0 ]]
        do
            until [[ $password != "" && $? == 0 ]]
            do
                read -p "Please type a password here: " password
            done
            manualgen=0
        done
    fi

    # PW Okay?
    read -p "Password '$password' okay? [Y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]] ; then
        pwsuccess=1
    else
        pwsuccess=0
        autogen=1
        manualgen=0
    fi

done

# Set password
    echo "$clientname:$password" | sudo chpasswd
    if [[ $? -eq 0 ]] ; then
        echo "Password set successfully."
    else
        echo "There was an error setting the password. Cannot continue."
        echo "Please set one using the 'sudo passwd $clientname' command manually."
        echo "Aborting..."
        exit 1
    fi

# Create .ftpaccess
    echo -n "Creating .ftpaccess... "
    sudo touch /home/ftp/$clientname/.ftpaccess

# Permissions
    sudo chown $clientname:$clientname /home/ftp/$clientname/.ftpaccess

# Populate
    sudo echo -e "<Limit ALL>\n# Allow All\nAllow 0.0.0.0/0\n</Limit>" > /home/ftp/$clientname/.ftpaccess
    echo "Successful."


# Complete
    echo "Script completed."
    exit 0
