<?php

const API_BASE_URL = 'https://api-default.avantlink.net/';

$api = new api();

$email = readline('Arches email address: ');

shell_exec('stty -echo');
echo 'Arches password: ';
$password = trim(fgets(STDIN, 4096));
shell_exec('stty echo');

$response = $api->call('login', 'POST', ['email_address' => $email, 'password' => $password]);
if (!array_key_exists('authorization_role', $response)) {
    die('Error getting authorization role.');
}

while ($response['authorization_role'] == 'ROLE_PRE_ACCESS') {
    $api->call('authy/verification', 'POST', ['send_method' => 'sms']);
    $mfa_code = readline('Enter 2FA code: ');

    $response = $api->call('login/authy/verification/verify', 'POST', ['verification_code' => $mfa_code, 'device_nickname' => 'Merchant Ads Script']);
}

if ($response['authorization_role'] != 'ROLE_USER') {
    die('There is an error with your token. The authorization role is ' . $response['authorization_role']);
}

do {
    $copy_from = readline('Merchant Id to copy FROM (Classic Id or UUID): ');
    $copy_to = readline('Merchant Id to copy TO (Classic Id or UUID): ');

    if (is_numeric($copy_from) && strlen($copy_from) == 5) {
        $copy_from = $api->getMerchantIdFromClassicId($copy_from);
    }
    if (is_numeric($copy_to) && strlen($copy_to) == 5) {
        $copy_to = $api->getMerchantIdFromClassicId($copy_to);
    }

    $from = $api->getMerchant($copy_from);
    $to = $api->getMerchant($copy_to);

    $continue = readline("Copying ads from $from[merchant_name] ($from[merchant_network]) to $to[merchant_name] ($to[merchant_network]). Continue? [y/n] ");;
} while (strtolower($continue) != 'y');

$ads = $api->call("merchants/$copy_from/ads");

echo 'Copying ' . count($ads['items']) . " ads.\n";

foreach ($ads['items'] as $ad) {
    $data = [
        'ad_type' => $ad['ad_type'],
        'ad_title' => $ad['ad_title'],
        'link_text' => $ad['link_text'],
        'promotion_details' => $ad['promotion_details'],
        'destination_url' => $ad['destination_url'],
        'start_date' => $ad['start_date'],
        'end_date' => $ad['end_date']
    ];

    if ($ad['ad_type'] == 'banner') {
        $banner_file = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $ad['merchant_ad_id'] . '_' . $ad['ad_image_file_name'];
        $fp = fopen($banner_file, 'w');
        if ($fp !== false) {
            fwrite($fp, file_get_contents($ad['image_url']));
            fclose($fp);

            $data['image_file'] = new \CURLFile($banner_file, mime_content_type($banner_file), $ad['ad_original_image_name']);
        }
    }

    if (!empty($ad['coupon_code'])) {
        $coupon_code = $api->call("merchants/$copy_to/coupon_codes", 'POST', ['coupon_code' => $ad['coupon_code']['coupon_code']]);
        if (array_key_exists('coupon_code_id', $coupon_code)) {
            $data['coupon_code_id'] = $coupon_code['coupon_code_id'];
        }
    }

    $new_ad = $api->call("merchants/$copy_to/ads", 'POST', $data);

    if (!empty($ad['tags'])) {
        foreach ($ad['tags'] as $ad_tag) {
            $tag = $api->call('tags', 'POST', [
                'tag_name' => $ad_tag['tag_name'],
                'tag_type' => 'merchant_ad',
            ]);

            $api->call("tags/entity/$new_ad[merchant_ad_id]/merchant_ads", 'POST', ['tag_id' => $tag['tag_id']]);
        }
    }
}

echo "Done!\n";

class api
{
    private $headers;

    function __construct()
    {
        $this->headers = [
            'X-API-Version' => '2.0',
            'Authorization' => 'ecbd33850ec41b6f41700db1575f5adb75db3a48;403f2c5c7b754d94b95752f23b4e380d4b994e55;1478209357;0067300c-5389-4158-abb7-5e701888b098;P100Y'
        ];

        if (is_file($this->getUserDeviceIdFile())) {
            $this->headers['user_device_id'] = file_get_contents($this->getUserDeviceIdFile());
        }
    }

    function getMerchantIdFromClassicId($classic_id)
    {
        $merchant = $this->call("merchants/$classic_id");
        if (array_key_exists('merchant_id', $merchant)) {
            $merchant_id = $merchant['merchant_id'];
        }
        else {
            var_dump($merchant);
            die("Unable to find merchant $merchant");
        }

        return $merchant_id;
    }

    function getMerchant($merchant_id) {
        return $this->call("merchants/$merchant_id");
    }

    function getUserDeviceIdFile()
    {
        return sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'device_id.txt';
    }

    function call($endpoint, $method = 'GET', $data = [])
    {
        $url = API_BASE_URL . $endpoint;

        $header_data = [];
        foreach ($this->headers as $key => $value) {
            $header_data[] = "$key: $value";
        }

        if ($endpoint == 'login' && array_key_exists('user_device_id', $this->headers) && !array_key_exists('user_device_id', $data)) {
            $data['user_device_id'] = $this->headers['user_device_id'];
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header_data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36');

        switch ($method) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                break;

            case 'PUT':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                break;
        }

        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }

        $response = curl_exec($ch);

        $info = curl_getinfo($ch);
        if ($info['http_code'] != 200) {
            $json = json_decode($response, true);
            if (empty($json)) {
                $error = $response;
            } else {
                $error = $json['error'];
            }
            die("There was an error with the API request: $error");
        }

        curl_close($ch);

        $json = json_decode($response, true);
        if (empty($json)) {
            $json = $response;
        }

        if (array_key_exists('authorization', $json)) {
            $this->headers['Authorization'] = $json['authorization'];
        }

        if (array_key_exists('user_device_id', $json)) {
            $this->headers['user_device_id'] = $json['user_device_id'];

            $fp = fopen($this->getUserDeviceIdFile(), 'w');
            if ($fp !== false) {
                fwrite($fp, $json['user_device_id']);
                fclose($fp);
            }
        }

        return $json;
    }
}
