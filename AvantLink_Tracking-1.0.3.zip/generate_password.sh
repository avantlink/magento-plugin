#!/bin/bash
# Generate the password and save it to the user.
# This script is used by (post) https://api.avantlink.com/batch/{merchant_id}/user
# AND (put) https://api.avantlink.com/batch/{merchant_id}/user/password
# Please do not modify this file with out notifying the development team.
# @author Johnny Umberger

username=$1
password=""

autogen=1
#Auto-generate.
until [ $autogen == 0 ]
do
    password="$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 12 | head -n 1)"

    if [[ $password != "" && $? -eq 0 ]] ; then
      autogen=0
    fi
done

#Set the password to the user.
echo "$username:$password" | chpasswd
if [[ $? -ne 0 ]] ; then
    echo "{\"error\": \"There was an error setting the password.\"}"
    exit 1
fi

echo "{\"password\": \"$password\"}"
