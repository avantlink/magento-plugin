<?php

namespace AvantLink\Tracking\Observer;

use Magento\Framework\Event\ObserverInterface;
use \Magento\Checkout\Model\Session as CheckoutSession;

class OrderData implements \Magento\Framework\Event\ObserverInterface
{
    protected $resultPageFactory;
    protected $dataHelper;
    protected $checkoutSession;
    public function __construct(
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Session\SessionManagerInterface $session,
        \AvantLink\Tracking\Helper\Data $dataHelper,
        CheckoutSession $checkoutSession
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->session = $session;
        $this->dataHelper = $dataHelper;
        $this->_checkoutSession = $checkoutSession;
    }
   public function execute(\Magento\Framework\Event\Observer $observer)
   {
       $orderData = [];
       $order = $observer->getEvent()->getOrder();
       $orderData['orderId'] = $order->getIncrementId();
       $orderData['customerId'] = $order->getCustomerId();
       $orderData['subTotal'] = $order->getSubtotal();
       $orderData['couponCode'] = $order->getCouponCode();
       $orderData['currencyCode'] = $order->getOrderCurrencyCode();
       $orderData['taxAmount'] = $order->getTaxAmount();
       $orderData['countryCode'] = $order->getBillingAddress()->getCountryId();
       $orderData['stateCode'] = $order->getBillingAddress()->getRegionCode();

       $items = $order->getItems();
       $itemsArray = [];
       foreach($items as $item) {
           $itemsArray[] = [
               'itemQty' => $item->getQtyOrdered(),
               'itemPrice' => $item->getPrice(),
               'itemSku' => $item->getSku()
           ];
       }
       $orderData['items'] = $itemsArray;

       $helper = $this->dataHelper;
       $merchantId = $helper->getMerchantId();
       $orderData['merchantId'] = $merchantId;

       $this->_checkoutSession->setData('order_data', json_encode($orderData));
   }
}