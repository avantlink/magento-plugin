<?php
namespace AvantLink\Tracking\Block\Checkout;

use Magento\Checkout\Block\Onepage\Success as MagentoSuccess;
use Magento\Framework\View\Element\Template;
use Magento\Checkout\Model\Session as CheckoutSession;

class Success extends Template
{
        protected $checkoutSession;

        public function __construct(
            Template\Context $context,
            CheckoutSession $checkoutSession,
            array $data = []
        ) {
            $this->checkoutSession = $checkoutSession;
            parent::__construct($context, $data);
        }

        public function getOrderData() {
            $orderData = $this->checkoutSession->getData('order_data');
            $this->checkoutSession->unsetData('order_data');
            return $orderData;
        }
}
