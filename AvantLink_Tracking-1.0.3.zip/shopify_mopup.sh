sudo mv /home/ftp/datafeeds/shopify/shopify.log /home/ftp/datafeeds/shopify/archive/shopify`date +%Y%m%d_%H%M%S`.log 
sudo touch /home/ftp/datafeeds/shopify/shopify.log
sudo chown -R datafeeds:datafeeds /home/ftp/datafeeds/shopify/shopify.log
sudo chmod 777 /home/ftp/datafeeds/shopify/shopify.log
