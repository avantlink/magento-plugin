<?php
namespace AvantLink\Tracking\ViewModel;

class GetConfigData implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    /**
     * @var \AvantLink\Tracking\Helper\Data
     */
    private $helperData;

    /**
     * @param \AvantLink\Tracking\Helper\Data $helperData
     */
    public function __construct(
        \AvantLink\Tracking\Helper\Data $helperData
    ) {
        $this->helperData = $helperData;
    }

    /**
     * Calls the helper to get the merchant id value from store config
     *
     * @return mixed
     */
    public function getSettingValue()
    {
        return $this->helperData->getMerchantId();
    }
}
