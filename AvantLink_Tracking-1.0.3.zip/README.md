# integration
Client integration scripts.

##Setting up a crontab for shopify

01 00 * * *   php /home/ubuntu/scripts/shopify_new.php 'Shipify Key' 'Shopify Password' 'Shopify Store' >> /home/ftp/datafeeds/shopify/shopify.log 2>&1 && sudo mv #shopifyStore#.csv /home/ftp/datafeeds/shopify/#shopifyStore#.csv && sudo chown datafeeds:datafeeds /home/ftp/datafeeds/shopify/#shopifyStore#.csv

#### ARCHIVE SHOPIFY LOGS @ NOON EVERYDAY.
00 12 * * *   bash /home/ubuntu/scripts/shopify_mopup.sh

#### PSA preprocessor to remove ^M line ending bullocks
23 23 * * *   bash /home/ubuntu/scripts/psa-remove-control-m.sh

#### Revup sports preprocessor to gunzip
32 23 * * *   bash /home/ubuntu/scripts/revup-gunzip.sh


##Deploying avantlink-integration-for-woocommerce
* Grab latest code from git repo
* check out source from svn repo `svn co https://plugins.svn.wordpress.org/avantlink-integration-for-woocommerce`
* Copy changed code from git to svn trunk/
* create tag `svn copy trunk tags/{tagid}`
* commit change ` svn ci --username avantlink -m "Commit Message" ` The passwords is what is used for the word press login. 
* Validate updates on https://wordpress.org/plugins/avantlink-integration-for-woocommerce/#description