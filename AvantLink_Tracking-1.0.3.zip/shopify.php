<?php

// Datafeed Column Layouts:
// WITHOUT IBC:
    // primary:   strProductSKU|strAttribute1|strAttribute2|strAttribute3|strAttribute4|strProductName|strAttribute5|txtLongDescription|strBrandName|strDepartment|txtProductKeywords|dblProductPrice|dblProductSalePrice|strBuyURL|strAttribute6|strAttribute7|strLargeImage|strMediumImage|strThumbnailImage|strAttribute8|strAttribute9|strAttribute10|txtAttribute2|txtAttribute3|txtAttribute4|txtAttribute5|txtAttribute6|txtAttribute7|txtAttribute8|txtAttribute9|txtAttribute10|txtAttribute1
    // secondary: strProductSKU|variant-sku|variant-upc|variant-vendor_id|variant-vendor_sku|variant-product-title|variant-title|variant-body-html||||variant-retail_price|variant-sale_price|variant-detail_url||variant-image_url|variant-image-large|variant-image-medium|variant-image-thumbnail|variant-size|variant-color|variant-style|||||||||

// WITH IBC:
    // primary:   strProductSKU|strAttribute1|strAttribute2|strAttribute3|strAttribute4|strProductName|strAttribute5|txtLongDescription|strBrandName|strDepartment|txtProductKeywords|dblProductPrice|dblProductSalePrice|strBuyURL|strAttribute6|strAttribute7|strLargeImage|strMediumImage|strThumbnailImage|strAttribute8|strAttribute9|strAttribute10|txtAttribute2|txtAttribute3|txtAttribute4|txtAttribute5|txtAttribute6|txtAttribute7|txtAttribute8|txtAttribute9|txtAttribute10|txtAttribute1|dblItemBasedCommission
    // secondary: strProductSKU|variant-sku|variant-upc|variant-vendor_id|variant-vendor_sku|variant-product-title|variant-title|variant-body-html||||variant-retail_price|variant-sale_price|variant-detail_url||variant-image_url|variant-image-large|variant-image-medium|variant-image-thumbnail|variant-size|variant-color|variant-style||||||||||

define('CHARSET', 'UTF-8');

if ($argc != 4 && $argc != 5) {
    echo "Usage: php shopify.php [key] [password] [store-name] [Optional `ibc` for IBC]\n";
    echo "Note: IBC data takes much longer to pull, so please only use this parameter if the merchant is using IBC\n";
    exit;
}

$key = $argv[1];
$password = $argv[2];
$store = $argv[3];
$ibc = false;

if ($argc == 5 && trim(strtolower($argv['4'])) == 'ibc') {
    $ibc = true;
}

class Shopify
{
    private $shopify_key;
    private $shopify_password;
    private $shopify_store;
    private $shopify_url;
    private $check_ibc;

    public function __construct($key, $password, $store, $check_ibc)
    {
        $this->shopify_key = $key;
        $this->shopify_password = $password;
        $this->shopify_store = $store;
        $this->shopify_url = 'https://' . $this->shopify_store . '.myshopify.com/admin/api/2024-04/';
        $this->check_ibc = $check_ibc;
    }

    public function makeRequest($url_slug, $method, $query = '')
    {
        $url = $this->curlAppendQuery($this->shopify_url . $url_slug, $query);
        $handle = curl_init($url);
        $this->curlSetopts($handle, $method);

        $response_headers = [];
        curl_setopt($handle, CURLOPT_HEADERFUNCTION,
            function($curl, $header) use (&$response_headers)
            {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;

                $response_headers[strtolower(trim($header[0]))][] = trim($header[1]);

                return $len;
            }
        );

        $response = curl_exec($handle);
        $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        curl_close($handle);

        if ($httpCode != 200) {
            switch ($httpCode) {
                case 303:
                    $message = 'See Other - The response to the request can be found under a different URI in the Location header and can be retrieved using a GET method on that resource.';
                    break;
                case 400:
                    $message = 'Bad Request - The request was not understood by the server, generally due to bad syntax or because the Content-Type header was not correctly set to application/json.\nThis status is also returned when the request provides an invalid code parameter during the OAuth token exchange process.';
                    break;
                case 401:
                    $message = 'Unauthorized - The necessary authentication credentials are not present in the request or are incorrect.';
                    break;
                case 402:
                    $message = 'Payment Required - The requested shop is currently frozen.';
                    break;
                case 403:
                    $message = 'Forbidden - The server is refusing to respond to the request. This is generally because you have not requested the appropriate scope for this action.';
                    break;
                case 404:
                    $message = 'Not Found - The requested resource was not found but could be available again in the future.';
                    break;
                case 406:
                    $message = 'Not Acceptable - The requested resource is only capable of generating content not acceptable according to the Accept headers sent in the request.';
                    break;
                case 422:
                    $message = 'Un-processable Entity - The request body was well-formed but contains semantical errors. The response body will provide more details in the errors parameter.';
                    break;
                case 429:
                    $message = 'Too Many Requests - The request was not accepted because the application has exceeded the rate limit. See the API Call Limit documentation for a breakdown of Shopify\'s rate-limiting mechanism.';
                    break;
                case 500:
                    $message = 'Internal Server Error - An internal error occurred in Shopify. Please post to the API & Technology forum so that Shopify staff can investigate.';
                    break;
                case 501:
                    $message = 'Not Implemented - The requested endpoint is not available on that particular shop, e.g. requesting access to a Plus-specific API on a non-Plus shop. This response may also indicate that this endpoint is reserved for future use.';
                    break;
                case 503:
                    $message = 'Service Unavailable - The server is currently unavailable. Check the status page for reported service outages.';
                    break;
                case 504:
                    $message = 'Gateway Timeout - The request could not complete in time. Try breaking it down in multiple smaller requests.';
                    break;
                default:
                    $message = 'Unknown Error';
                    break;
            }

            echo $this->shopify_store . " " . date(" Ymd_H_i_s") . ": Shopify API Responded With: $httpCode $message\n\n EXITING\n\n";
            exit;
        }

        return ['headers' => $response_headers, 'body' => $response];
    }

    // ============================================================================
    // GET THE DATA FROM SHOPIFY
    // ============================================================================
    public function getFeed()
    {
        $filename = $this->shopify_store . '.csv';

        $response = $this->makeRequest('products/count.json', 'GET', array('published_status' => 'published'));
        $products_count = $response['body'];
        $limit = 250;
        $products_count = json_decode($products_count, true);
        $pages = ceil($products_count["count"] / $limit);
        $response = $this->makeRequest('shop.json', 'GET');
        $shop_get = $response['body'];
        $shop_info = json_decode($shop_get, true);
        $file = fopen($filename, "w");

        $headers = array(
            'Product SKU Name',
            'Product ID',
            'Product Variant SKU',
            'Product Variant Barcode',
            'Product Variant ID',
            'Product Variant Inventory Item ID',
            'Product Title',
            'Product Variant Title',
            'Product Long Description',
            'Product Short Description',
            'Product brand',
            'Product Category',
            'Product Google Category',
            'Product Keyword Tags',
            'Product Variant Retail Price',
            'Product Variant Sale Price',
            'Product Variant Buy URL',
            'Product Variant Image ID',
            'Product Variant Image',
            'Product Variant Large Image',
            'Product Variant Medium Image',
            'Product Variant Thumbnail Image',
            'Product Variant Option 1',
            'Product Variant Option 2',
            'Product Variant Option 3',
            'Product Variant Inventory Quantity',
            'Product Variant Old Inventory Quantity',
            'Product Variant Grams',
            'Product Variant Weight',
            'Product Variant Weight Unit',
            'Product Variant Requires Shipping',
            'Product Variant Fulfillment Service',
            'Product Variant Inventory Management'
        );

        if ($this->check_ibc) {
            $headers[] = 'Commission Rate';
        }

        fputcsv($file, $headers);

        echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Total Unique Products Pull Count: $products_count[count]\n";
        echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Start Looping thru Feed...\n";
        echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Please be patient as this takes time (est 1 min per 50K Product Variants)...\n";

        $page_info = '';

        for ($i = 1; $i <= $pages; $i++) {
            $params = array("limit" => $limit);
            if (!empty($page_info)) {
                $params['page_info'] = $page_info;
            }
            else {
                $params['published_status'] = 'published';
            }
            $response = $this->makeRequest('products.json', 'GET', $params);
            $matches = [];
            if (isset($response['headers']['link'][0]) && preg_match('#<[A-Za-z0-9:/\?\.\&\-_=]*page_info=([A-Za-z0-9]*)[A-Za-z0-9:/\?\.\&\-_=]*>; rel="next"#', $response['headers']['link'][0], $matches)) {
                $page_info = $matches[1];
            }
            else {
                $page_info = '';
            }
            $products = $response['body'];
            $products = json_decode($products, true);

            $str_find_array = $this->getFind();
            $str_replace_array = $this->getReplace();

            foreach ($products["products"] as $product) {
                $product_id = $product['id'];
                $product_commission = 0;

                if ($this->check_ibc) {
                    $response = $this->makeRequest('products/' . $product['id'] . '/metafields.json', 'GET', ['limit' => 250]);
                    $metadata = json_decode($response['body'], true);
                    foreach ($metadata['metafields'] as $data) {
                        if (preg_match('/commission[ _-]*?rate/i', $data['key'])
                            && is_numeric($data['value'])
                            && $data['value'] > 0
                        ) {
                            $product_commission = $data['value'];
                        }
                    }
                    // IBC checking causes so many frequent API calls that if we don't wait, we run into rate limits.
                    usleep(100000);
                }

                $product_id_handle = $product['handle'];
                $product_title = trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $product['title'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($product['title']))));

                $product_body_raw = $product['body_html'];
                $product_body_raw = preg_replace('/(\r\n|\r|\n)+/', '<br/>', $product_body_raw);
                $product_body_raw = strip_tags($product_body_raw);
                $product_body_raw = str_replace($str_find_array, $str_replace_array, $product_body_raw);
                $product_body_raw = mb_convert_encoding($product_body_raw, 'UTF-8', mb_detect_encoding($product_body_raw));
                $product_body_html = trim($product_body_raw);

                $product_body_short_raw = $product['body_html'];
                $product_body_short_raw = preg_replace('/(\r\n|\r|\n)+/', '<br/>', $product_body_short_raw);
                $product_body_short_raw = strip_tags($product_body_short_raw);
                $product_body_short_raw = str_replace($str_find_array, $str_replace_array, $product_body_short_raw);
                $product_body_short_raw = mb_convert_encoding($product_body_short_raw, 'UTF-8', mb_detect_encoding($product_body_short_raw));
                $product_body_short_html = trim($product_body_short_raw);
                if (strlen($product_body_short_html) > 140) {
                    $product_body_short_html = substr($product_body_short_html,0,140) . '...';
                }

                $product_brand = trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $product['vendor'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($product['vendor']))));
                $product_product_type = trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $product['product_type'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($product['product_type']))));
                $product_google_category = $product['product_type'];
                $product_image = $product['image']['src'];
                $product_url = 'https://' . $shop_info['shop']['domain'] . '/products/' . $product['handle'];
                $product_keyword_tags = htmlspecialchars_decode(trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $product['tags'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($product['tags'])))));

                foreach ($product['variants'] as $variant) {
                    $product_variant_id = $variant['id'];
                    $product_variant_title = trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $variant['title'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($variant['title']))));
                    $product_variant_retail_price = mb_convert_encoding($variant['price'], 'UTF-8', mb_detect_encoding(strip_tags($variant['price'])));
                    $product_variant_sku = mb_convert_encoding($variant['sku'], 'UTF-8', mb_detect_encoding(strip_tags($variant['sku'])));
                    $product_variant_sale_price = mb_convert_encoding($variant['compare_at_price'], 'UTF-8', mb_detect_encoding(strip_tags($variant['compare_at_price'])));
                    $product_variant_fulfillment_service = mb_convert_encoding($variant['fulfillment_service'], 'UTF-8', mb_detect_encoding(strip_tags($variant['fulfillment_service'])));
                    $product_variant_inventory_management = mb_convert_encoding($variant['inventory_management'], 'UTF-8', mb_detect_encoding(strip_tags($variant['inventory_management'])));
                    $product_variant_option1 = trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $variant['option1'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($variant['option1']))));
                    $product_variant_option2 = trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $variant['option2'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($variant['option2']))));
                    $product_variant_option3 =  trim(mb_convert_encoding(str_replace($str_find_array, $str_replace_array, strip_tags( $variant['option3'] ) ), 'UTF-8', mb_detect_encoding(strip_tags($variant['option3']))));
                    $product_variant_barcode = mb_convert_encoding($variant['barcode'], 'UTF-8', mb_detect_encoding(strip_tags($variant['barcode'])));
                    $product_variant_grams = mb_convert_encoding($variant['grams'], 'UTF-8', mb_detect_encoding(strip_tags($variant['grams'])));
                    $product_variant_image_id = mb_convert_encoding($variant['image_id'], 'UTF-8', mb_detect_encoding($variant['image_id']));
                    $product_variant_inventory_quantity = mb_convert_encoding($variant['inventory_quantity'], 'UTF-8', mb_detect_encoding(strip_tags($variant['inventory_quantity'])));
                    $product_variant_weight = mb_convert_encoding($variant['weight'], 'UTF-8', mb_detect_encoding(strip_tags($variant['weight'])));
                    $product_variant_weight_unit = mb_convert_encoding($variant['weight_unit'], 'UTF-8', mb_detect_encoding(strip_tags($variant['weight_unit'])));
                    $product_variant_inventory_item_id = mb_convert_encoding($variant['inventory_item_id'], 'UTF-8', mb_detect_encoding(strip_tags($variant['inventory_item_id'])));
                    $product_variant_old_inventory_quantity = mb_convert_encoding($variant['old_inventory_quantity'], 'UTF-8', mb_detect_encoding(strip_tags($variant['old_inventory_quantity'])));
                    $product_variant_requires_shipping = mb_convert_encoding($variant['requires_shipping'], 'UTF-8', mb_detect_encoding(strip_tags($variant['requires_shipping'])));
                    $product_variant_image   = $product_image;
                    $product_variant_buy_url = $product_url . '?variant=' . $variant['id'];

                    foreach ($product['images'] as $image) {
                        if ($image['id'] === $product_variant_image_id) {
                            $product_variant_image = $image['src'];
                        }
                    }

                    $product_variant_large_image = preg_replace('#(\.[a-zA-Z]{3}\?)#', '_1024x1024$1', $product_variant_image);
                    $product_variant_medium_image = preg_replace('#(\.[a-zA-Z]{3}\?)#', '_300x300$1', $product_variant_image);
                    $product_variant_thumbnail_image = preg_replace('#(\.[a-zA-Z]{3}\?)#', '_100x100$1', $product_variant_image);

                    // ============================================================================
                    // MAKEREQUEST - BUILD ARRAY
                    // DONT FORGET TO UPDATE THE HEADER ROW THAT TIES IN WITH THE ARRAY ORDER WRITTEN.
                    // ============================================================================
                    $fields = array(
                        // PRODUCT VARIATION ID's
                            $product_id_handle,
                            $product_id,
                            $product_variant_sku,
                            $product_variant_barcode,
                            $product_variant_id,
                            $product_variant_inventory_item_id,

                       // PRODUCT INFO
                            $product_title, // PRODUCT NAME
                            $product_variant_title, // PRODUCT TITLE

                            $product_body_html, // PRODUCT LONG DESCRIPTION
                            $product_body_short_html, // PRODUCT SHORT DESCRIPTION
                            $product_brand, // PRODUCT VENDOR
                            $product_product_type, // PRODUCT DEPARTMENT
                            $product_google_category, // PRODUCT GOOGLE CATEGORY
                            $product_keyword_tags, // PRODUCT KEYWORDS

                        // PRODUCT VARIANTS
                            $product_variant_retail_price, // PRODUCT RETAIL PRICE
                            $product_variant_sale_price, // PRODUCT SALE PRICE
                            $product_variant_buy_url,
                            $product_variant_image_id,
                            $product_variant_image,
                            $product_variant_large_image,
                            $product_variant_medium_image,
                            $product_variant_thumbnail_image,
                            $product_variant_option1,
                            $product_variant_option2,
                            $product_variant_option3,

                        // PRODUCT VARIANT INVENTORY COUNTS
                            $product_variant_inventory_quantity,
                            $product_variant_old_inventory_quantity,

                        // PRODUCT VARIANT MEASUREMENTS
                            $product_variant_grams,
                            $product_variant_weight,
                            $product_variant_weight_unit,
                            $product_variant_requires_shipping,

                        // PRODUCT VARIANT MISC.
                            $product_variant_fulfillment_service,
                            $product_variant_inventory_management
                    );

                    if ($this->check_ibc) {
                        $fields[] = $product_commission;
                    }

                    fputcsv($file, $fields);
                }
            }

            if (($products_count['count'] - ($limit * $i)) > 0) {
                echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Products Left To Pull : " . ($products_count['count'] - ($limit * ($i - 0))) . "\n";
            } else {
                echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Products Left To Pull : 0...Done!\n";
            }

            if ($page_info == '') {
                break;
            }
        }

        echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Finished Loop Thru Feed: $filename\n";

        fclose($file);
    }

    private function curlSetopts($ch, $method)
    {
        $headers = array(
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode($this->shopify_key . ':' . $this->shopify_password)
        );

        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_USERAGENT, 'shopify-php-api-client');
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    }

    private function curlAppendQuery($url, $query)
    {
        if (empty($query)) {
            return $url;
        }

        if (is_array($query)) {
            return "$url?" . http_build_query($query);
        } else {
            return "$url?$query";
        }

    }

    private function getFind()
    {
        return array('?', "\xc2\xbf", "\xc3\x80", "\xc3\x81", "\xc3\x82", "\xc3\x83", "\xc3\x84", "\xc3\x85", "\xc3\x86", "\xc3\x87", "\xc3\x88", "\xc3\x89", "\xc3\x8a", "\xc3\x8b", "\xc3\x8c", "\xc3\x8d", "\xc3\x8e", "\xc3\x8f", "\xc3\x90", "\xc3\x91", "\xc3\x92", "\xc3\x93", "\xc3\x94", "\xc3\x95", "\xc3\x96", "\xc3\x97", "\xc3\x98", "\xc3\x99", "\xc3\x9a", "\xc3\x9b", "\xc3\x9c", "\xc3\x9d", "\xc3\x9e", "\xc3\x9f", "\xc3\xa0", "\xc3\xa1", "\xc3\xa2", "\xc3\xa3", "\xc3\xa4", "\xc3\xa5", "\xc3\xa6", "\xc3\xa7", "\xc3\xa8", "\xc3\xa9", "\xc3\xaa", "\xc3\xab", "\xc3\xac", "\xc3\xad", "\xc3\xae", "\xc3\xaf", "\xc3\xb0", "\xc3\xb1", "\xc3\xb2", "\xc3\xb3", "\xc3\xb4", "\xc3\xb5", "\xc3\xb6", "\xc3\xb7", "\xc3\xb8", "\xc3\xb9", "\xc3\xba", "\xc3\xbb", "\xc3\xbc", "\xc3\xbd", "\xc3\xbe", "\xc3\xbf", "\xc2\xad", "\xe2\x80\xa8", "\xC2\x96", "\xc2\x99", "\xef\xa0\x80", "\xef\xa0\x81", "\xef\xa0\x82", "\xef\xa0\x83", "\xef\xa0\x84", "\xef\xa0\x85", "\xef\xa0\x86", "\xef\xa0\x87", "\xef\xa0\x88", "\xef\xa0\x89", "\xef\xa0\x8a", "\xef\xa0\x8b", "\xef\xa0\x8c", "\xef\xa0\x8d", "\xef\xa0\x8e", "\xef\xa0\x8f", "\xef\xa0\x90", "\xef\xa0\x91", "\xef\xa0\x92", "\xef\xa0\x93", "\xef\xa0\x94", "\xef\xa0\x95", "\xef\xa0\x96", "\xef\xa0\x97", "\xef\xa0\x98", "\xef\xa0\x99", "\xef\xa0\x9a", "\xef\xa0\x9b", "\xef\xa0\x9c", "\xef\xa0\x9d", "\xef\xa0\x9e", "\xef\xa0\x9f", "\xef\xa0\xa0", "\xef\xa0\xa1", "\xef\xa0\xa2", "\xef\xa0\xa3", "\xef\xa0\xa4", "\xef\xa0\xa5", "\xef\xa0\xa6", "\xef\xa0\xa7", "\xef\xa0\xa8", "\xef\xa0\xa9", "\xef\xa0\xaa", "\xef\xa0\xab", "\xef\xa0\xac", "\xef\xa0\xad", "\xef\xa0\xae", "\xef\xa0\xaf", "\xef\xa0\xb0", "\xef\xa0\xb1", "\xef\xa0\xb2", "\xef\xa0\xb3", "\xef\xa0\xb4", "\xef\xa0\xb5", "\xef\xa0\xb6", "\xef\xa0\xb7", "\xef\xa0\xb8", "\xef\xa0\xb9", "\xef\xa0\xba", "\xef\xa0\xbb", "\xef\xa0\xbc", "\xef\xa0\xbd", "\xef\xa0\xbe", "\xef\xa0\xbf", "\xef\xa1\x80", "\xef\xa1\x81", "\xef\xa1\x82", "\xef\xa1\x83", "\xef\xa1\x84", "\xef\xa1\x85", "\xef\xa1\x86", "\xef\xa1\x87", "\xef\xa1\x88", "\xef\xa1\x89", "\xef\xa1\x8a", "\xef\xa1\x8b", "\xef\xa1\x8c", "\xef\xa1\x8d", "\xef\xa1\x8e", "\xef\xa1\x8f", "\xef\xa1\x90", "\xef\xa1\x91", "\xef\xa1\x92", "\xef\xa1\x93", "\xef\xa1\x94", "\xef\xa1\x95", "\xef\xa1\x96", "\xef\xa1\x97", "\xef\xa1\x98", "\xef\xa1\x99", "\xef\xa1\x9a", "\xef\xa1\x9b", "\xef\xa1\x9c", "\xef\xa1\x9d", "\xef\xa1\x9e", "\xef\xa1\x9f", "\xef\xa1\xa0", "\xef\xa1\xa1", "\xef\xa1\xa2", "\xef\xa1\xa3", "\xef\xa1\xa4", "\xef\xa1\xa5", "\xef\xa1\xa6", "\xef\xa1\xa7", "\xef\xa1\xa8", "\xef\xa1\xa9", "\xef\xa1\xaa", "\xef\xa1\xab", "\xef\xa1\xac", "\xef\xa1\xad", "\xef\xa1\xae", "\xef\xa1\xaf", "\xef\xa1\xb0", "\xef\xa1\xb1", "\xef\xa1\xb2", "\xef\xa1\xb3", "\xef\xa1\xb4", "\xef\xa1\xb5", "\xef\xa1\xb6", "\xef\xa1\xb7", "\xef\xa1\xb8", "\xef\xa1\xb9", "\xef\xa1\xba", "\xef\xa1\xbb", "\xef\xa1\xbc", "\xef\xa1\xbd", "\xef\xa1\xbe", "\xef\xa1\xbf", "\xef\xa2\x80", "\xef\xa2\x81", "\xef\xa2\x82", "\xef\xa2\x83", "\xef\xa2\x84", "\xef\xa2\x85", "\xef\xa2\x86", "\xef\xa2\x87", "\xef\xa2\x88", "\xef\xa2\x89", "\xef\xa2\x8a", "\xef\xa2\x8b", "\xef\xa2\x8c", "\xef\xa2\x8d", "\xef\xa2\x8e", "\xef\xa2\x8f", "\xef\xa2\x90", "\xef\xa2\x91", "\xef\xa2\x92", "\xef\xa2\x93", "\xef\xa2\x94", "\xef\xa2\x95", "\xef\xa2\x96", "\xef\xa2\x97", "\xef\xa2\x98", "\xef\xa2\x99", "\xef\xa2\x9a", "\xef\xa2\x9b", "\xef\xa2\x9c", "\xef\xa2\x9d", "\xef\xa2\x9e", "\xef\xa2\x9f", "\xef\xa2\xa0", "\xef\xa2\xa1", "\xef\xa2\xa2", "\xef\xa2\xa3", "\xef\xa2\xa4", "\xef\xa2\xa5", "\xef\xa2\xa6", "\xef\xa2\xa7", "\xef\xa2\xa8", "\xef\xa2\xa9", "\xef\xa2\xaa", "\xef\xa2\xab", "\xef\xa2\xac", "\xef\xa2\xad", "\xef\xa2\xae", "\xef\xa2\xaf", "\xef\xa2\xb0", "\xef\xa2\xb1", "\xef\xa2\xb2", "\xef\xa2\xb3", "\xef\xa2\xb4", "\xef\xa2\xb5", "\xef\xa2\xb6", "\xef\xa2\xb7", "\xef\xa2\xb8", "\xef\xa2\xb9", "\xef\xa2\xba", "\xef\xa2\xbb", "\xef\xa2\xbc", "\xef\xa2\xbd", "\xef\xa2\xbe", "\xef\xa2\xbf", "\xef\xa3\x80", "\xef\xa3\x81", "\xef\xa3\x82", "\xef\xa3\x83", "\xef\xa3\x84", "\xef\xa3\x85", "\xef\xa3\x86", "\xef\xa3\x87", "\xef\xa3\x88", "\xef\xa3\x89", "\xef\xa3\x8a", "\xef\xa3\x8b", "\xef\xa3\x8c", "\xef\xa3\x8d", "\xef\xa3\x8e", "\xef\xa3\x8f", "\xef\xa3\x90", "\xef\xa3\x91", "\xef\xa3\x92", "\xef\xa3\x93", "\xef\xa3\x94", "\xef\xa3\x95", "\xef\xa3\x96", "\xef\xa3\x97", "\xef\xa3\x98", "\xef\xa3\x99", "\xef\xa3\x9a", "\xef\xa3\x9b", "\xef\xa3\x9c", "\xef\xa3\x9d", "\xef\xa3\x9e", "\xef\xa3\x9f", "\xef\xa3\xa0", "\xef\xa3\xa1", "\xef\xa3\xa2", "\xef\xa3\xa3", "\xef\xa3\xa4", "\xef\xa3\xa5", "\xef\xa3\xa6", "\xef\xa3\xa7", "\xef\xa3\xa8", "\xef\xa3\xa9", "\xef\xa3\xaa", "\xef\xa3\xab", "\xef\xa3\xac", "\xef\xa3\xad", "\xef\xa3\xae", "\xef\xa3\xaf", "\xef\xa3\xb0", "\xef\xa3\xb1", "\xef\xa3\xb2", "\xef\xa3\xb3", "\xef\xa3\xb4", "\xef\xa3\xb5", "\xef\xa3\xb6", "\xef\xa3\xb7", "\xef\xa3\xb8", "\xef\xa3\xb9", "\xef\xa3\xba", "\xef\xa3\xbb", "\xef\xa3\xbc", "\xef\xa3\xbd", "\xef\xa3\xbe", "\xef\xa3\xbf", "\xef\xbb\xbf", ' ', '♪', '♭', '¼', '½', '⅓', '⅔', '⅕', '⅖', '⅗', '⅘', '⅙', '⅚', '⅛', '⅜', '⅝', '¾', '⅞', 'Ⓢ', '|', '?', '$', '!', ';', 'à', '·', '¶', '¯', '«', 'ª', '¨', '§', '¦', '¥', '¤', '£', '¢', '¡', '"', '″', '‘', '`', '°', '¢', '∞', '¬', '*', ',', '…', '–', '—', '%', '“', '”', '„', '˝', '•', '’', chr(145), chr(146), chr(147), chr(148), chr(151), '&#8222;', '&#8220;', '&#146;', '©', '®', 'Ⓡ', 'ⓡ', '™', '~\x{00a0}~siu', "\r\n", "\n", ' ');
    }

    private function getReplace()
    {
        return array( '&quest;',    '&#xBF;',   '&#xC0;',   '&#xC1;',   '&#xC2;',   '&#xC3;',   '&#xC4;',   '&#xC5;',   '&#xC6;',   '&#xC7;',   '&#xC8;',   '&#xC9;',   '&#xCA;',   '&#xCB;',   '&#xCC;',   '&#xCD;',   '&#xCE;',   '&#xCF;',   '&#xD0;',   '&#xD1;',   '&#xD2;',   '&#xD3;',   '&#xD4;',   '&#xD5;',   '&#xD6;',   '&#xD7;',   '&#xD8;',   '&#xD9;',   '&#xDA;',   '&#xDB;',   '&#xDC;',   '&#xDD;',   '&#xDE;',   '&#xDF;',   '&#xE0;',   '&#xE1;',   '&#xE2;',   '&#xE3;',   '&#xE4;',   '&#xE5;',   '&#xE6;',   '&#xE7;',   '&#xE8;',   '&#xE9;',   '&#xEA;',   '&#xEB;',   '&#xEC;',   '&#xED;',   '&#xEE;',   '&#xEF;',   '&#xF0;',   '&#xF1;',   '&#xF2;',   '&#xF3;',   '&#xF4;',   '&#xF5;',   '&#xF6;',   '&#xF7;',   '&#xF8;',   '&#xF9;',   '&#xFA;',   '&#xFB;',   '&#xFC;',   '&#xFD;',   '&#xFE;',   '&#xFF;',          '',             '',             '',          '',              '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',            '',              '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',             '',            '&nbsp;',  '&sung;', '&flat;', '&frac14;', '&frac12;', '&frac13;', '&frac23;', '&frac15;', '&frac25;', '&frac35;', '&frac45;', '&frac16;', '&frac56;', '&frac18;', '&frac38;', '&frac58;', '&frac34;', '&frac78;',  '&oS;', '&verbar;',       '?', '&dollar;', '&excl;',      ';',   '&agrave;', '&middot;', '&para;', '&macr;', '&laquo;', '&ordf;',  '&uml;', '&sect;', '&brvbar;',  '&yen;',  '&curren;', '&pound;', '&cent;', '&iexcl;', '&quot;', '&quot;',  '\'', '&grave;',  '&deg;', '&cent;',  '&infin;',    '&not;',   '&ast;',      '&comma;', '&hellip;',  '&ndash;', '&mdash;', '&percnt;', '&quot;', '&quot;', '&quot;',  '&quot;', '&bull;', '\'',      "'",      "'",      '"',      '"',      '-',       '"',       '"',      "'",  '&copy;', '&reg;', '&reg;', '&reg;', '&trade;',              '',   '<br/>',   '<br/>', ' ');
    }
}

echo "$store " . date("Ymd_H_i_s") . ": SHOPIFY_STORE Used:    $store\n";
echo "$store " . date("Ymd_H_i_s") . ": SHOPIFY_KEY Used:      $key\n";
echo "$store " . date("Ymd_H_i_s") . ": SHOPIFY_PASSWORD Used: $password\n";

if ($ibc) {
    echo "$store " . date("Ymd_H_i_s") . ": Pulling IBC Data\n";
}

$shopify = new Shopify($key, $password, $store, $ibc);
$shopify->getFeed();
