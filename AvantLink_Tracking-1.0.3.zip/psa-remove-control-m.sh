#!/bin/sh

# PSA Conversion Hack | Owen 2018-03-29
#######################################
# PSA has ^M control char line endings which must be
# manually removed from AvantLinkFeed04.xml, which has
# their IBC. The 05 datafeed is just their DOTD feed.

# This script will do the quick, ugly, dirty work.
# Cronjobbed.

# Log DateTime
starttime=`date`
echo "$starttime" >> /home/ftp/datafeeds/preprocessor.log
echo "PSA Preprocessor" >> /home/ftp/datafeeds/preprocessor.log

# If existing, remove and log
if [ -f /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml ]; then 
	sudo rm /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml;
	echo "Removed Existing Processed Feed" >> /home/ftp/datafeeds/preprocessor.log
fi

# Get file
curl "https://palmettostatearmory.com/amfeed/main/get/file/AvantlinkFeed04/AvantlinkFeed04.xml" > psa-ibc-feed.xml;
if [ -f /home/ubuntu/scripts/psa-ibc-feed.xml ]; then
	echo "Downloaded psa-ibc-feed.xml" >> /home/ftp/datafeeds/preprocessor.log;
fi

# Trim the ^M (aka \r) and redirect std output
tr -d '\r\003' < psa-ibc-feed.xml > psa-ibc-preprocessed.xml;

#permission hackery
sudo cp psa-ibc-preprocessed.xml /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml;
sudo chown datafeeds:datafeeds /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml;

# remove temp files
sudo rm psa-ibc-feed.xml
sudo rm psa-ibc-preprocessed.xml

# Check and log success
if [ -f /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml ]; then
	if ! grep -on $'\r' /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml; then
		echo "Success; /home/ftp/datafeeds/pre_screened/psa-ibc-preprocessed.xml created and no ^M wonkyness found." >> /home/ftp/datafeeds/preprocessor.log;
		echo "" >> /home/ftp/datafeeds/preprocessor.log; # Blank line
	fi
fi



