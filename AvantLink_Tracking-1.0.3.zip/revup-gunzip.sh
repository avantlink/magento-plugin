#! /bin/sh

# Revup - Owen - 2018-07-30
# We don't support gzip feeds natively.
# 19 MB vs 500MB unzipped... easier to do it on our side.
# I tested and it only takes 1s to download and 3s to gunzip

# Log DateTime
starttime=`date`
echo "$starttime" >> /home/ftp/datafeeds/preprocessor.log
echo "Revup Gunzip Preprocessor" >> /home/ftp/datafeeds/preprocessor.log

# If existing, remove and log
if [ -f /home/ftp/datafeeds/pre_screened/revupsports-MercentProduct.txt ]; then 
        sudo rm /home/ftp/datafeeds/pre_screened/revupsports-MercentProduct.txt;
        echo "Removed Existing Processed Feed" >> /home/ftp/datafeeds/preprocessor.log
fi

# Fetch and check
curl "https://revupsports.com/media/mercentfeed/MercentProduct.txt.gz" > MercentProduct.txt.gz
if [ -f /home/ubuntu/scripts/MercentProduct.txt.gz ]; then
        echo "Downloaded MercentProduct.txt.gz" >> /home/ftp/datafeeds/preprocessor.log;
fi

# Unzip
sudo gunzip MercentProduct.txt.gz

# Move and chown
sudo cp MercentProduct.txt /home/ftp/datafeeds/pre_screened/revupsports-MercentProduct.txt
sudo chown datafeeds:datafeeds /home/ftp/datafeeds/pre_screened/revupsports-MercentProduct.txt

# remove temp files
sudo rm MercentProduct.txt

# Check and log success
if [ -f /home/ftp/datafeeds/pre_screened/revupsports-MercentProduct.txt ]; then
	echo "Success; /home/ftp/datafeeds/pre_screened/revupsports-MercentProdut.txt created and unzipped." >> /home/ftp/datafeeds/preprocessor.log;
	echo "" >> /home/ftp/datafeeds/preprocessor.log; # Blank line
fi



