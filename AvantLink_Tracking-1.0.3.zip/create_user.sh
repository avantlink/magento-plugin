#!/bin/bash
# Add User for Batch (FTP, Returns, Sales)
# This script is used by (post) https://api.avantlink.com/batch/{merchant_id}/user
# Please do not modify this file with out notifying the development team.
# @author Johnny Umberger

username=$1

# Setup the users.
create_user=$(useradd --create-home --groups ftp --shell=/dev/null --home-dir=/home/ftp/"$username" "$username" 2>&1 >/dev/null)

# Catch stderr
if [ $? -ne 0 ]; then
    echo "{\"error\": \"$create_user\"}"
    exit 1
fi

create_dir=$(mkdir /home/ftp/"$username"/{returns,sales} 2>&1 >/dev/null)

# Catch stderr
if [ $? -ne 0 ] ; then
    echo "{\"error\": \"$create_dir\"}"
    exit 1
fi

# Create .ftpaccess
touch /home/ftp/"$username"/.ftpaccess

#Set permissions so we can write to it.
chmod 777 /home/ftp/"$username"/.ftpaccess

# Populate
echo -e "<Limit ALL>\n# Allow All\nAllow 0.0.0.0/0\n</Limit>" > /home/ftp/"$username"/.ftpaccess

#Set permissions
chmod 644 /home/ftp/"$username"/.ftpaccess
chown -R "$username": /home/ftp/"$username"/{returns,sales}

echo "{\"success\": \"$username FTP user added.\"}"