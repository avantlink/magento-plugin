<?php

define('CHARSET', 'UTF-8');

if ($argc != 4 && $argc != 5) {
    echo "Usage: php shopify-returns.php [key] [password] [store-name]\n";
    exit;
}

$key = $argv[1];
$password = $argv[2];
$store = $argv[3];

$order_id_check = readline('Comma Separates list of Shopify Order Id\'s (no spaces): ');

class Shopify_Return
{
    private $shopify_key;
    private $shopify_password;
    private $shopify_store;
    private $shopify_url;
    private $order_id_input;

    public function __construct($key, $password, $store, $order_id_input)
    {
        $this->shopify_key = $key;
        $this->shopify_password = $password;
        $this->shopify_store = $store;
        $this->shopify_url = 'https://' . $this->shopify_store . '.myshopify.com/admin/api/2024-01/';
        $this->order_id_input = $order_id_input;
    }

    public function makeRequest($url_slug, $method, $query = '')
    {
        $url = $this->curlAppendQuery($this->shopify_url . $url_slug, $query);
        $handle = curl_init($url);
        $this->curlSetopts($handle, $method);

        $response_headers = [];

        curl_setopt($handle, CURLOPT_HEADERFUNCTION,
            function($curl, $header) use (&$response_headers)
            {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) > 2)
                    return $len;
                if (array_key_exists(1, $header)) {
                    $response_headers[strtolower(trim($header[0]))][] = trim($header[1]);
                } else {
                    $response_headers[strtolower(trim($header[0]))][] = trim($header[0]);
                }
                return $len;
            }
        );

        $response = curl_exec($handle);
        $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        curl_close($handle);

        if ($httpCode != 200) {
            switch ($httpCode) {
                case 303:
                    $message = 'See Other - The response to the request can be found under a different URI in the Location header and can be retrieved using a GET method on that resource.';
                    break;
                case 400:
                    $message = 'Bad Request - The request was not understood by the server, generally due to bad syntax or because the Content-Type header was not correctly set to applicaton/json.\nThis status is also returned when the request provides an invalid code parameter during the OAuth token exchange process.';
                    break;
                case 401:
                    $message = 'Unauthorized - The necessary authentication credentials are not present in the requrest or are incorrect.';
                    break;
                case 402:
                    $message = 'Payment Required - The requested shop is currently frozen.';
                    break;
                case 403:
                    $message = 'Forbidden - The server is refusing to respond to the request. This is generally because you have not requested the appropriate scope for this action.';
                    break;
                case 404:
                    $message = 'Not Found - The requested resource was not found but could be available again in the future.';
                    break;
                case 406:
                    $message = 'Not Acceptable - The requested resource is only capable of generating content not acceptable according to the Accept headers sent in the request.';
                    break;
                case 422:
                    $message = 'Un-processable Entity - The request body was well-formed but contains semantical errors. The response body will provide more details in the errors parameter.';
                    break;
                case 429:
                    $message = 'Too Many Requests - The request was not accepted because the applicationhas exceeded the rate limit. See the API Call Limit documentation for a breakdown of Shopify\'s rate-limiting mechanism.';
                    break;
                case 500:
                    $message = 'Internal Server Error - An internal error occured in Shopify. Please post to the API & Technology forum so that Shopify staff can investigate.';
                    break;
                case 501:
                    $message = 'Not Implemented - The requested endpoint is not available on that particular shop, e.g. requesting access to a Plus-speific API on a non-Plus shop. This response may also indicate that this endpoint is reserver for future use.';
                    break;
                case 503:
                    $message = 'Service Unavailable - The server is currently unavailable. Check the status page for reported service outages.';
                    break;
                case 504:
                    $message = 'Gateway Timeout - The request could not complete in time. Try breaking it down in multiple smaller requests.';
                    break;
                default:
                    $message = 'Unknown Error';
                    break;
            }

            echo $this->shopify_store . " " . date(" Ymd_H_i_s") . ": Shopify API Responded With: $httpCode $message\n\n EXITING\n\n";
            exit;
        }

        return ['headers' => $response_headers, 'body' => $response];
    }

    // ============================================================================
    // GET THE DATA FROM SHOPIFY
    // ============================================================================
    public function getOrders()
    {
        $filename = $this->shopify_store . '.csv';
        $file = fopen($filename, "w");

        $headers = array(
            'Transaction/Order Id',
            'Product ID/SKU',
            'Return Item Amount',
            'Return Item Quantity',
            'Return Reason Code'
        );

        fputcsv($file, $headers);

        echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Start Looping thru Orders...\n";

        $order_numbers = $this->order_id_input;
        if (!empty($order_numbers)) {
            $params['ids'] = $order_numbers;
        }
        $params['status'] = 'cancelled';
        $currentDate = new DateTime();
        $sixtyDaysAgo = $currentDate->modify('-60 day')->format('c');
        $params['created_at_min'] = $sixtyDaysAgo;

        $response = $this->makeRequest('orders.json', 'GET', $params);

        $orders = $response['body'];
        $orders = json_decode($orders, true);


        foreach($orders["orders"] as $order) {
            $refunds = $order['refunds'];
            if (count($refunds) > 0) {
                foreach ($refunds as $refund) {
                    foreach ($refund['refund_line_items'] as $refund_item) {
                        $order_id = $order['id'];
                        $refund_item_sku = $refund_item['line_item']['sku'];
                        $refund_item_amount = $refund_item['subtotal'];
                        $refund_item_quantity = $refund_item['line_item']['quantity'];
                        $refund_return_reason = 'RETURN';

                        $fields = array(
                            $order_id,
                            $refund_item_sku,
                            $refund_item_amount,
                            $refund_item_quantity,
                            $refund_return_reason
                        );

                        fputcsv($file, $fields);

                    }
                }
            }
        }

        echo $this->shopify_store . " " . date("Ymd_H_i_s") . ": Finished Loop Thru Orders...";

        fclose($file);
    }

    public function curlSetopts($ch, $method) {
        $headers = array(
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode($this->shopify_key. ':' . $this->shopify_password)
        );

        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_USERAGENT, 'shopify-php-api-client');
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    }

    private function curlAppendQuery($url, $query) {
        if (empty($query)) {
            return $url;
        }

        if (is_array($query)) {
            return "$url?" . http_build_query($query);
        } else {
            return "$url?$query";
        }
    }

}

echo "$store " . date("Ymc_H_i_s") . ": SHOPIFY_STORE Used:     $store\n";
echo "$store " . date("Ymc_H_i_s") . ": SHOPIFY_KEY Used:       $key\n";
echo "$store " . date("Ymc_H_i_s") . ": SHOPIFY_PASSWORD Used:  $password\n";

$shopify = new Shopify_Return($key, $password, $store, $order_id_check);
$shopify->getOrders();