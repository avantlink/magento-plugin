<?php

if ($argc != 3) {
    die ('Usage: php backcountry_datafeed_preprocessor.php [input_file] [output_file]');
}

$input_file = $argv[1];
$output_file = $argv[2];
$temp_input_file = tempnam(sys_get_temp_dir(), 'bc_');
$temp_output_file = tempnam(sys_get_temp_dir(), 'bc_');

copy($input_file, $temp_input_file);

$input_fp = fopen($temp_input_file, 'r');
$tmp_fp = fopen($temp_output_file, 'w');

$headers = fgetcsv($input_fp);
$headers[0] = str_replace(chr(hexdec('EF')).chr(hexdec('BB')).chr(hexdec('BF')), '', ($headers[0]));
$headers[] = 'Variants XML';
fputcsv($tmp_fp, $headers);

$current_sku = '';
$product = [];
$variants = [];

while ($row = fgetcsv($input_fp)) {
    $parent_sku = preg_replace('#\-.*$#', '', $row[0]);

    if ($parent_sku != $row[0]) {
        $variants[] = [
            'sku' => htmlspecialchars($row[0]),
            'image_url' => htmlspecialchars($row[4]),
            'detail_url' => htmlspecialchars($row[5]),
            'retail_price' => htmlspecialchars($row[6]),
            'vendor_sku' => htmlspecialchars($row[7]),
            'sale_price' => htmlspecialchars($row[15]),
            'upc' => htmlspecialchars($row[19])
        ];
    }

    if ($current_sku != $parent_sku) {
        if ($current_sku != '') {
            writeProduct($tmp_fp, $product, $variants);
            $variants = [];
        }

        $current_sku = $parent_sku;
        $product = $row;
    }
}

writeProduct($tmp_fp, $product, $variants);

fclose($input_fp);
fclose($tmp_fp);

copy($temp_output_file, $output_file);

unlink($temp_input_file);
unlink($temp_output_file);

function writeProduct($fp, $product, $variants)
{
    $variants_xml = '';

    if ($variants) {
        $variants_xml .= '<variants>';
        foreach ($variants as $variant) {
            $variants_xml .= '<variant>';
            foreach ($variant as $key => $value) {
                $variants_xml .= "<$key>$value</$key>";
            }
            $variants_xml .= '</variant>';
        }
        $variants_xml .= '</variants>';
    }

    $product[] = $variants_xml;

    fputcsv($fp, $product);
}