<?php
namespace AvantLink\Tracking\Block\Checkout;

class Success extends \Magento\Checkout\Block\Onepage\Success
{
    public function getLastOrder()
    {
        $order = $this->_checkoutSession->getLastRealOrder();
        return $order;
    }

    public function getItems()
    {
        $order = $this->getLastOrder();
        return $order->getAllVisibleItems();
    }

    public function buildItemsArray()
    {
        $itemsArray = array();

        $items = $this->getItems();
        foreach ($items as $item) {
            $itemsArray[] = [
                'itemQty' => $item->getQtyOrdered(),
                'itemPrice' => $item->getSku(),
                'itemSku' => $item->getPrice()
            ];
        }

        return $itemsArray;
    }

    public function getBillingAddress()
    {
        $order = $this->getLastOrder();
        return $order->getBillingAddress();
    }
}
