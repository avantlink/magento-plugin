<?php
/**
 * This script will move the ftp batch files from the merchants directory into the Arches API which will trigger the batch process job.
 *
 */

//--------CONFIG---------------------------
$starting_dir = '/home/ftp/';
$api_url = 'https://api.avantlink.com';
$api_authorization = '0d88aadc3de871df5fd1a1c79671ea01449c76c1;72654608a68820b1e777791c35bac1d33ad00fdc;1519751363;74d2aa72-1b0a-11e8-accf-0ed5f89f718b;P100Y';
// -------End Config-----------------------


/**
 * Install
 *
 * "apt-get install util-linux" or "apt-get install flock"
 *
 * #crontab
 * "* * * * * /usr/bin/flock -w 0 /home/ubuntu/scripts/submit_batch_files_to_arches.lock php /home/ubuntu/scripts/submit_batch_files_to_arches.php"
 *
 */

$ArchesAPI = new ArchesAPI($api_url, $api_authorization);

$users = $ArchesAPI->apiBatchUserRequest();

if (empty($users)) {
    echo 'No Users where returned from the API, cant continue.';
    exit;
}

$files = getDirContents($starting_dir);

$errors = [];

foreach ($files as $file) {
    $file_pieces = explode('/', $file);
    $batch_type = $file_pieces[count($file_pieces) - 2];
    $batch_user = $file_pieces[count($file_pieces) - 3];

    if (in_array($batch_type, ['returns', 'sales'])) {
        $key = array_search($batch_user, array_column($users, 'user_name'));
        if ($key !== false) {
            $response = $ArchesAPI->apiPostBatchFile($file, $users[$key]['merchant_id'], $batch_type);
            if (isset($response['batch_history_id'])) {
                unlink($file);
            } else {
                $errors[] = ['error' => $response['error']];
            }
        } else {
            $errors[] = ['error' => 'error: unable to find username: ' . $batch_user];
        }
    }
}

//todo do something with the errors ???
print_r($errors);


/**
 * Simple class for hitting the arches API batch endpoints needed for this script
 * Class ArchesAPI
 */
class ArchesAPI
{
    private $_authorization = '';
    private $_url = '';


    public function __construct($url, $authorization)
    {
        $this->_authorization = $authorization;
        $this->_url = $url;
    }

    /**
     * hit the /batch/user endpoint
     * @return mixed
     */
    public function apiBatchUserRequest()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->_url . '/batch/user');

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'X-API-Version: 2.0',
            'Authorization: ' . $this->_authorization
        ]);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $response = curl_exec($ch);
        $response = json_decode($response, true);

        curl_close($ch);

        return $response;
    }

    /**
     * hit the {post} /batch/{merchant_id} endpoint
     * @param $file
     * @param $merchant_id
     * @param $batch_type
     * @return mixed
     */
    public function apiPostBatchFile($file, $merchant_id, $batch_type)
    {
        //the API expects it to be return, not returns
        if ($batch_type == 'returns') {
            $batch_type = 'return';
        }

        $fields = [
            'batch_file' => curl_file_create($file, mime_content_type($file)),
            'upload_method' => 'SFTP',
            'batch_type' => $batch_type
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->_url . '/batch/' . $merchant_id);

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'X-API-Version: 2.0',
            'Authorization: ' . $this->_authorization
        ]);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);

        $response = curl_exec($ch);
        $response = json_decode($response, true);

        curl_close($ch);

        return $response;
    }
}


function getDirContents($dir, &$results = array())
{
    $two_weeks_timestamp = strtotime('- 2 weeks');
    $files = @scandir($dir);

    if(is_array($files)) {
        foreach ($files as $key => $value) {
            $path = @realpath($dir . DIRECTORY_SEPARATOR . $value);
            if (!is_dir($path)) {
                if (filemtime($path) >= $two_weeks_timestamp) {
                    $results[] = $path;
                }
            } else {
                if ($value != "." && $value != "..") {
                    getDirContents($path, $results);
                }
            }
        }
    }

    return $results;
}

