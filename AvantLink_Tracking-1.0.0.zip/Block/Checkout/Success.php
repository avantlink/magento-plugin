<?php
namespace AvantLink\Tracking\Block\Checkout;

use Magento\Checkout\Block\Onepage\Success as MagentoSuccess;
use Magento\Framework\View\Element\Template\Context;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order\Config;
use Magento\Framework\App\Http\Context as HttpContext;

class Success extends MagentoSuccess
{
    public function getLastOrder()
    {
        $order = $this->_checkoutSession->getLastRealOrder();
        return $order;
    }

    public function getItems()
    {
        $order = $this->getLastOrder();
        return $order->getAllVisibleItems();
    }

    public function buildItemsArray()
    {
        $itemsArray = array();

        $items = $this->getItems();
        foreach ($items as $item) {
            $itemsArray[] = [
                'itemQty' => $item->getQtyOrdered(),
                'itemPrice' => $item->getPrice(),
                'itemSku' => $item->getSku()
            ];
        }

        return $itemsArray;
    }

    public function getBillingAddress()
    {
        $order = $this->getLastOrder();
        return $order->getBillingAddress();
    }
}
