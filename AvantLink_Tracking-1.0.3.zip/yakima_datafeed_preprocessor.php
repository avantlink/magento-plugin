<?php

if ($argc != 2) {
    die ('Usage: php yakima_datafeed_preprocessor.php [output_file]');
}

$output_file = $argv[1];

$file = file_get_contents('https://go.yakima.com/api/product/xmlfeed');
$file = str_replace(['xmlns:i="http://www.w3.org/2001/XMLSchema-instance"', 'xmlns="http://schemas.datacontract.org/2004/07/DealerFit.Data"'], '', $file);

$fp = fopen($output_file, 'w');
fwrite($fp, $file);
fclose($fp);
